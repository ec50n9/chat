export default definePageConfig({
  navigationBarTitleText: "社区",
});
